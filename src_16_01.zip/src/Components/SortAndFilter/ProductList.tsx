import React from 'react'
import { FormControl, Grid, InputLabel, MenuItem, Select, SelectChangeEvent, Typography } from '@mui/material'
import { Box } from '@mui/system'
import { Button } from '@mui/material';
import axios from 'axios';
import { useState, useEffect } from 'react';
import ShoppingCartSharpIcon from '@mui/icons-material/ShoppingCartSharp';
import Sortbar from './Sortbar';

const ProductList = (_category: any) => {
    let productList: any = []

    const [product, setProduct]: any = useState([])

    
    useEffect(() => {
        {
            axios.get(`http://localhost:8080/all/products/?category=`+_category.myList.myList)
            .then((res) => setProduct(res.data))
            .catch(err=>console.log(err))
            console.log("eeeeeeeee",_category);
            console.log("tyuhuhu",_category.myList);
            console.log("tyuhuh7876567u",_category.myList.myList);
            
            
        }
        // else{
        //     console.log("2332333");
        //     axios.get('http://localhost:8080/product')
        //     .then(res => {
        //         const loadedProducts: any = [];
        //         productList = [...res.data._embedded.products]
        //         for (const key in productList) {

        //             loadedProducts.push({
        //                 productName: productList[key].productName,
        //                 productPrice: productList[key].productPrice,
        //                 productImg: productList[key].productImg,
        //                 productDesc: productList[key].productDesc,
        //                 productCategory: productList[key].productCategory
        //             });

        //         }
        //         setProduct(loadedProducts);

        //     })

        // }
       
    },[]);
    console.log("Sssss",product);
    



    return (
        <Box>
            {/* <Box sx={{ minWidth: 200 }}>
                <Sortbar renderResult/>
            </Box> */}
            
            <Grid container spacing={5} sx={{ p: 4 }}>
                {product.map((product: any) => (
                    <Grid item md={4}>
                        <Box
                            sx={{ width: 300, height: 280 }}
                            component='img'
                            src={`${product.productImg}?w=164&h=164&fit=crop&auto=format`}
                        />
                        <Typography variant='h6' sx={{ fontWeight: "bold" }}>
                            {product.productName}
                        </Typography>
                        <Typography variant='body2'>
                            {product.productDesc}
                        </Typography>
                        <Typography variant='h5' sx={{ fontWeight: "bold", color: "#ff6d00" }}>
                            ₹ {product.productPrice}/-

                        </Typography>
                        <Button variant="outlined" startIcon={<ShoppingCartSharpIcon />}>
                            ADD TO CART
                        </Button>

                    </Grid>
                ))}

            </Grid>
        </Box>
    )
}

export default ProductList