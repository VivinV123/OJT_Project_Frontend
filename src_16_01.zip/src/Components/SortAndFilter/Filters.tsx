import { Select, MenuItem, InputLabel, Box, FormControl, Typography, SelectChangeEvent } from '@mui/material'
import Button from '@mui/material/Button'
import axios from 'axios'
import React, { Fragment, useEffect, useState } from 'react'
// import Category from '../Category'
import ProductList from './ProductList'
import Sortbar from './Sortbar'

type Props = {
    renderResult: any;
  }

function Filters({ }: Props) {
    let productList: any = []
    const [product, setProduct]: any = useState([])

    const [category, setCategory] = React.useState('selectone');
    const[selected0,setSelected0]=useState(false)
    const[selected1,setSelected1]=useState(false)
    const[selected2,setSelected2]=useState(false)



    const[sooo,setSooo]=useState('')
    
    const handleChange = (event: SelectChangeEvent) => {
        setCategory(event.target.value as string);
      };
    useEffect(() => {
     
        category===product[0]?setSelected0(true):setSelected0(false);  
        category===product[1]?setSelected1(true):setSelected1(false); 
        category===product[2]?setSelected2(true):setSelected2(false);  

        console.log("jjjdjdjddjdj",product);
       
        console.log("jjjdjd789dj",sooo);
      
        console.log("jjjdjd$%^&j",category);
      
        console.log("selected",selected0);
       },[category]);

    useEffect(() => {
        axios.get('http://localhost:8080/all/products')
            .then(res => {
                var arr=[]
                productList = [...res.data]
                for (const key in productList) {
                    arr.push(productList[key].productCategory)    
                }
              
                function onlyProduct(value: any, index: any, self: string | any[]) {
                    return self.indexOf(value) === index;
                  
                  }
                  var nonDuplicateProducts = arr.filter(onlyProduct);
                  setProduct(nonDuplicateProducts) 

              
                    
            })
           
    });
    
  
    return (
        <Fragment>

            <br />
            <Typography variant='h6'>
                Filters
            </Typography><br />

  
            <Box sx={{ minWidth: "10px" }}>
           
                <FormControl fullWidth>
                    <InputLabel id="demo-simple-select-label">Category</InputLabel>
                    <Select
                        labelId="demo-simple-select-label"
                        id="demo-simple-select"
                        value={category}
                        label="Category"
                    onChange={handleChange}
                    >
                         <MenuItem value="selectone">Select please</MenuItem>
                         {product.map((products: any) => ( 
                        <MenuItem value={products}> {products}</MenuItem>
                       
                        ))}
                         {/* {setSooo(product)} */}

                    </Select>
                </FormControl>
                
                
   
            </Box><br />
            
                {selected0 && <Sortbar myList={product[0]}/>}
                {selected1 && <Sortbar myList={product[1]}/>}
                {selected2 && <Sortbar myList={product[2]}/>}

        </Fragment>


    )
}

export default Filters