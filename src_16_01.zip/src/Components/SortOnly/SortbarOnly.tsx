import { SelectChangeEvent, Box, FormControl, InputLabel, Select, MenuItem } from '@mui/material';
import React, { useEffect, useState } from 'react'
import Filters from '../SortAndFilter/Filters';
import ProductHighToLow from '../SortAndFilter/ProductHighToLow';
import ProductHighToLowOnly from './ProductHighToLowOnly';
import ProductList from '../SortAndFilter/ProductList';
import ProductListOnly from './ProductListOnly';

import ProductLowToHighOnly from './ProductLowToHighOnly';

type Props = {
  renderResult: any;
}

const SortbarOnly = () => {
  const [price, setPrice] = React.useState('selectone');

  const[highToLow,sethighToLow]=useState(false)
  const[lowToHigh,setlowToHigh]=useState(false)
  const[unSorted,setunSorted]=useState(true)

  useEffect(() => {
   price==="Low to High"?setlowToHigh(true):setlowToHigh(false);
   price==="selectone"?setunSorted(true):setunSorted(false);
   price==="High to Low"?sethighToLow(true):sethighToLow(false);
   console.log("sssllllllss",lowToHigh);
   console.log("sshhhhhsss",highToLow);
   console.log("unSorted",unSorted);
   
  },[price]);

  const handleChange = (event: SelectChangeEvent) => {
    setPrice(event.target.value as string);
  };

  return (
    <Box sx={{ minWidth: 200 }}>
 
    <FormControl fullWidth>
      
      <InputLabel id="demo-simple-select-label">Sort By Price</InputLabel>
      <Select
        labelId="demo-simple-select-label"
        id="demo-simple-select"
        value={price}
        label="Sort By Price"
        onChange={handleChange}
      >
        <MenuItem value="selectone">Select please</MenuItem>
        <MenuItem value="Low to High">Low to High</MenuItem>
        <MenuItem value="High to Low">High to Low</MenuItem>
      </Select>
      
    </FormControl>
    
    {unSorted && <ProductListOnly/>}
    {highToLow && <ProductHighToLowOnly/>}
    {lowToHigh && <ProductLowToHighOnly/>}
    
  </Box>
  
  )
}

export default SortbarOnly;