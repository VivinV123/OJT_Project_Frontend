import React from 'react'
import { Box } from '@mui/material';
import Navbar from './Navbar';
import sizeConfig from '../Config/sizeConfig';
import ColorConfig from '../Config/ColorConfig';
import Toolbar from '@mui/material/Toolbar';
import { Outlet } from 'react-router-dom';
import Filters from './SortAndFilter/Filters';

import SortbarOnly from './SortOnly/SortbarOnly';


function Welcome() {
  return (
    <Box>
      <Navbar />

      <Box sx={{ display: "flex" }}>

        <Box
          component="nav"
          sx={{
            width: sizeConfig.sidebar.width,
            flexShrink: 0,
            backgroundColor: ColorConfig.sidebar.color
          }}
        >
          <Filters renderResult />
        </Box>


        <Box
          component="main"
          sx={{
            flexGrow: 1,
            p: 3,
            width: `calc(100% -${sizeConfig.sidebar.width})`,
            minHeight: "100vh",
            backgroundColor: ColorConfig.mainBg
          }}
        >


          <SortbarOnly />

          <Toolbar />
          <Outlet />

        </Box>

      </Box>
    </Box>


  )
}

export default Welcome;