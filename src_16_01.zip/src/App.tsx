import React, { Fragment } from 'react';
import Navbar from './Components/Navbar';
import Welcome from './Components/Welcome';
import { Routes, Route } from "react-router-dom"
import { Container } from '@mui/material';
import ProductList from './Components/SortAndFilter/ProductList';


const App = () => {
  return (


    <Fragment>
      <Welcome />
    </Fragment>

  );
}

export default App;
