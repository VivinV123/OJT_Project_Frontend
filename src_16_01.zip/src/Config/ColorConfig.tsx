
import { colors } from '@mui/material'

const ColorConfig ={
sidebar:{
    bg:"#233044",
    color:"#eeeeee",
    hoverBg:"#1e293a",
    activeBg:"#1e253a"
},
mainBg: colors.cyan
};
export default ColorConfig