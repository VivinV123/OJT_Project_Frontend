import React from 'react'

const sizeConfig ={
sidebar:{
    width:"300px"
},
sortbar:{
    width:"200px"
}
};

export default sizeConfig;