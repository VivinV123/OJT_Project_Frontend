import React from 'react'

const Sort = () => {
  return (
    <div>Sort</div>
  )
}

export default Sort