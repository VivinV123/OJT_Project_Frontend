import React from 'react'

type Props = {}

const SideBar = (props: Props) => {
  return (
    <div>SideBar</div>
  )
}

export default SideBar