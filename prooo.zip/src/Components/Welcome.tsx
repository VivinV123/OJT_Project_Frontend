import React, { Fragment } from 'react'

import { Box, Typography } from '@mui/material';
import Navbar from './Navbar';
import sizeConfig from '../Config/sizeConfig';
import Sortbar from './Sortbar';
import SideBar from './SideBar';
import ColorConfig from '../Config/ColorConfig';
import Toolbar from '@mui/material/Toolbar';
import { Outlet } from 'react-router-dom';
import ProductList from './ProductList';
import Filters from './Filters';


function Welcome() {
  return (
    <Box>
      <Navbar />

      <Box sx={{ display: "flex" }}>

        <Box
          component="nav"
          sx={{
            width: sizeConfig.sidebar.width,
            flexShrink: 0,
            backgroundColor: ColorConfig.sidebar.color
          }}
        >
  <Filters/>
        </Box>


        <Box
          component="main"
          sx={{
            flexGrow: 1,
            p: 3,
            width: `calc(100% -${sizeConfig.sidebar.width})`,
            minHeight: "100vh",
            backgroundColor: ColorConfig.mainBg
          }}
        >
        

          <Box sx={{ width: "100px" }}>
            <Sortbar />
          </Box>

          <ProductList />
          <Toolbar />
          <Outlet />

        </Box>

      </Box>
    </Box>


  )
}

export default Welcome;