import React from 'react'
import { Grid, Typography } from '@mui/material'
import { Box } from '@mui/system'
import { Button } from '@mui/material';
import axios from 'axios';
import { useState,useEffect } from 'react';
import ShoppingCartSharpIcon from '@mui/icons-material/ShoppingCartSharp';

const ProductList = () => {
    let productList: any = []

    const [product, setProduct]: any = useState([])
    useEffect(() => {
        axios.get('http://localhost:8080/product')
            .then(res => {
                const loadedProducts: any = [];
             productList = [...res.data._embedded.products]
                for (const key in productList) {
                    // console.log("prroki9o9wfd",key);
                    loadedProducts.push({
                        productName: productList[key].productName,
                        productPrice: productList[key].productPrice,
                        productImg: productList[key].productImg,
                        productDesc: productList[key].productDesc,
                        productCategory: productList[key].productCategory
                    });

                }
                setProduct(loadedProducts);
                // console.log("prrofd",product);
            })

    });

    // axios.get(`http://localhost:8080/product`).then((response) => {
    //     const productList = [...response.data._embedded.products]
    //     console.log("lisssss" + productList);
    //     console.log("lissssss345s" + JSON.stringify(productList));
    //     var count = Object(productList).length;
    //     console.log("count", count);
    //     const datas = JSON.stringify(productList);
    //     console.log("liss" + datas);






    // })
    return (
        <Grid container spacing={5} sx={{ p: 4 }}>
            {product.map( (product: any) => (
            <Grid item md={4}>
                <Box
                    sx={{ width: 300, height: 280 }}
                    component='img'
                    src={`${product.productImg}?w=164&h=164&fit=crop&auto=format`}
                    // src={product.productImg}
                />
                <Typography variant='h6' sx={{ fontWeight: "bold" }}>
                    {product.productName}
                </Typography>
                <Typography variant='body2'>
                {product.productDesc}
                  
                </Typography>
                <Typography variant='h5' sx={{ fontWeight: "bold", color: "#ff6d00" }}>
                    ₹ {product.productPrice}/-
             
                </Typography>
                <Button variant="outlined" startIcon={<ShoppingCartSharpIcon />}>
                    ADD TO CART
                </Button>
               
            </Grid>
             ))}
            {/* <Grid item md={3}>
                <Box
                    sx={{ width: "300px" , height:"300px"}}
                    component='img'
                    src='https://m.media-amazon.com/images/I/914hFeTU2-L._SL1500_.jpg'
                />
                <Typography variant='h6' sx={{ fontWeight: "bold" }}>
                    Samsung S10
                </Typography>
                <Typography variant='body2'>
                    Amazing display with high quality picture
                </Typography>
                <Typography variant='h5' sx={{ fontWeight: "bold", color: "#ff6d00" }}>
                    $90.00
                </Typography>
                <Typography variant='subtitle2' sx={{ color: "gray" }}>
                    $5.78 for shoping
                </Typography>
                <Button variant="outlined" startIcon={<ShoppingCartSharpIcon />}>
                    ADD TO CART
                </Button>
            </Grid>
            <Grid item md={3}>
                <Box
                    sx={{ width: "300px" , height:"300px"}}
                    component='img'
                    src='https://m.media-amazon.com/images/I/71geVdy6-OS._SX679_.jpg'
                />
                <Typography variant='h6' sx={{ fontWeight: "bold" }}>
                    Samsung S10
                </Typography>
                <Typography variant='body2'>
                    Amazing display with high quality picture
                </Typography>
                <Typography variant='h5' sx={{ fontWeight: "bold", color: "#ff6d00" }}>
                    $90.00
                </Typography>
                <Typography variant='subtitle2' sx={{ color: "gray" }}>
                    $5.78 for shoping
                </Typography>
                <Button variant="outlined" startIcon={<ShoppingCartSharpIcon />}>
                    ADD TO CART
                </Button>
            </Grid>
            <Grid item md={3}>
                <Box
                    sx={{ width: "300px" , height:"300px"}}
                    component='img'
                    src='https://m.media-amazon.com/images/I/71geVdy6-OS._SX679_.jpg'
                />
                <Typography variant='h6' sx={{ fontWeight: "bold" }}>
                    Samsung S10
                </Typography>
                <Typography variant='body2'>
                    Amazing display with high quality picture
                </Typography>
                <Typography variant='h5' sx={{ fontWeight: "bold", color: "#ff6d00" }}>
                    $90.00
                </Typography>
                <Typography variant='subtitle2' sx={{ color: "gray" }}>
                    $5.78 for shoping
                </Typography>
                <Button variant="outlined" startIcon={<ShoppingCartSharpIcon />}>
                    ADD TO CART
                </Button>
            </Grid>
            <Grid item md={3}>
                <Box
                    sx={{ width: "300px" , height:"300px"}}
                    component='img'
                    src='https://m.media-amazon.com/images/I/71geVdy6-OS._SX679_.jpg'
                />
                <Typography variant='h6' sx={{ fontWeight: "bold" }}>
                    Samsung S10
                </Typography>
                <Typography variant='body2'>
                    Amazing display with high quality picture
                </Typography>
                <Typography variant='h5' sx={{ fontWeight: "bold", color: "#ff6d00" }}>
                    $90.00
                </Typography>
                <Typography variant='subtitle2' sx={{ color: "gray" }}>
                    $5.78 for shoping
                </Typography>
                <Button variant="outlined" startIcon={<ShoppingCartSharpIcon />}>
                    ADD TO CART
                </Button>
            </Grid> */}
        </Grid>
    )
}

export default ProductList