import React,{Fragment} from 'react';
import Navbar from './Components/Navbar';
import Welcome from './Components/Welcome';
import {Routes, Route} from "react-router-dom"
import { Container } from '@mui/material';
import ProductList from './Components/ProductList';


const App=()=> {
  return (
 
 
    <Fragment>
    {/* <Navbar/> */}
    <Welcome/>
    {/* <ProductList/> */}
    {/* <Route path='/' element={<Navbar/>} />
    <Route path='/welcome' element={<Welcome/>} /> */}
    </Fragment>
 
    // <Fragment>
    //   <Routes>
    //     <Route path='/' element={<Navbar/>} />
    //     <Route path='/welcome' element={<Welcome/>} />
    //   </Routes>
    
    // </Fragment>
  );
}

export default App;
